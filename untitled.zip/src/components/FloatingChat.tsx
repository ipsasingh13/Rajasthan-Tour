import { Bot, Send, X } from 'lucide-react';
import React, { useState } from 'react';
import { ChatMessage } from '../types';

export default function FloatingChat() {
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatLogs, setChatLogs] = useState<ChatMessage[]>([
    { id: 1, sender: 'bot', text: 'Khamma Ghani! Welcome. I am your Royal Caravan planner bot. Ask me for customized budget advisory, packing secrets, or city guides.' }
  ]);

  const sendChat = () => {
    if (!chatInput.trim()) return;
    const newLogs = [...chatLogs, { id: Date.now(), sender: 'user' as const, text: chatInput }];
    setChatLogs(newLogs);
    
    const prompt = chatInput.toLowerCase();
    let reply = "Based on royal defense maps, I suggest assigning at least 2 days for Fort segments with a local palace accommodation.";
    
    if (prompt.includes('temple') || prompt.includes('religious')) {
      reply = "✨ Spiritual Route Advisory:\n- Day 1: Proceed to Khatu Shyam Ji & Salasar Balaji.\n- Day 2: Pushkar Lake & ancient Brahma temple.";
    } else if (prompt.includes('20,000') || prompt.includes('budget')) {
      reply = "💰 Budget Optimizations:\n- Travel via reliable sleeper train routes.\n- Book traditional family homestays in old town Jaisalmer.";
    } else if (prompt.includes('family') || prompt.includes('trip plan')) {
      reply = "🏰 Family Caravan Plan:\n- Choose Jaipur and Udaipur. Comfort and leisure pacing matches perfectly for multi-generational groups.";
    }

    setChatInput('');
    setTimeout(() => {
      setChatLogs(prev => [...prev, { id: Date.now(), sender: 'bot', text: reply }]);
    }, 500);
  };

  const triggerQuickQuestion = (q: string) => {
    setChatInput(q);
    setTimeout(sendChat, 0); // Need to wait for state to update or pass directly
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 font-sans">
      <button onClick={() => setChatOpen(!chatOpen)} className="bg-indigo-600 text-white p-4 rounded-full shadow-2xl flex items-center justify-center hover:bg-indigo-700 transition duration-200">
        {!chatOpen ? <Bot className="w-6 h-6" /> : <X className="w-6 h-6" />}
      </button>

      {chatOpen && (
        <div className="absolute bottom-16 right-0 w-[340px] sm:w-[390px] bg-white border border-slate-200 rounded-2xl shadow-2xl flex flex-col h-[460px] overflow-hidden animate-in slide-in-from-bottom-10 duration-300">
          <div className="bg-white p-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-slate-800 tracking-tight">AI Assistant</span>
            </div>
            <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-1 rounded-full uppercase font-bold tracking-widest flex items-center gap-1.5">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
              </span>
              Online
            </span>
          </div>
          
          <div className="flex-grow p-4 overflow-y-auto space-y-3 text-sm bg-slate-50">
            {chatLogs.map(msg => (
              <div key={msg.id} className={msg.sender === 'user' ? 'text-right' : 'text-left'}>
                <div className={`${msg.sender === 'user' ? 'bg-indigo-600 text-white ml-auto' : 'bg-white border border-slate-200 text-slate-700'} inline-block p-3 rounded-2xl shadow-sm max-w-[85%] whitespace-pre-line leading-relaxed`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-white border-t border-slate-100 flex flex-wrap gap-2">
            {['Best temples?', 'Budget trip under ₹20,000?', 'Family trip plan?'].map(q => (
              <button key={q} onClick={() => { setChatInput(q); setTimeout(sendChat, 0); }} className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-[11px] font-medium text-slate-600 px-3 py-1.5 rounded-full transition">
                {q}
              </button>
            ))}
          </div>

          <div className="p-3 bg-white border-t border-slate-100 flex items-center gap-2">
            <input 
              type="text" 
              value={chatInput} 
              onChange={e => setChatInput(e.target.value)} 
              onKeyUp={e => e.key === 'Enter' && sendChat()} 
              placeholder="Type message to AI..." 
              className="w-full bg-slate-50 text-sm text-slate-800 p-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
            <button onClick={sendChat} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold p-2.5 rounded-xl transition shadow-sm">
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
