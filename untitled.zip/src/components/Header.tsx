import {
  Crown,
  MapPin,
  Megaphone
} from 'lucide-react';
import React from 'react';
import { translations } from '../data';
import { Language, Page } from '../types';

interface HeaderProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  currentLang: Language;
  setCurrentLang: (lang: Language) => void;
  isLoggedIn: boolean;
}

export default function Header({ currentPage, setCurrentPage, currentLang, setCurrentLang, isLoggedIn }: HeaderProps) {
  const t = (key: string) => translations[currentLang][key] || translations['en'][key];

  return (
    <header className="flex flex-col w-full bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="bg-indigo-600 text-indigo-50 text-[11px] py-2 px-4 text-center font-medium flex justify-between items-center w-full">
        <span className="hidden sm:flex items-center gap-1.5"><Crown className="w-3.5 h-3.5" /> {t('welcomeBar')}</span>
        <span className="mx-auto sm:mx-0 flex items-center gap-1.5"><Megaphone className="w-3.5 h-3.5" /> Special Autumn Offer: Get Free Camel Safari vouchers on smart planner booking!</span>
        <span className="hidden md:flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> Rajasthan, India</span>
      </div>

      <div className="max-w-7xl w-full mx-auto px-6 py-4 flex flex-wrap justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setCurrentPage('home')}>
          <div className="w-8 h-8 bg-indigo-600 rounded-md flex items-center justify-center">
            <div className="w-4 h-4 border-2 border-white rounded-sm"></div>
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-800">ROYAL.IO</span>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          <button onClick={() => setCurrentPage('home')} className={`${currentPage === 'home' ? 'text-indigo-600' : 'hover:text-slate-900'} transition`}>{t('navHome')}</button>
          <button onClick={() => setCurrentPage('planner')} className={`${currentPage === 'planner' ? 'text-indigo-600' : 'hover:text-slate-900'} transition`}>{t('navPlanner')}</button>
          <button onClick={() => setCurrentPage('explore')} className={`${currentPage === 'explore' ? 'text-indigo-600' : 'hover:text-slate-900'} transition`}>{t('navCulture')}</button>
          <button onClick={() => setCurrentPage('interactive')} className={`${currentPage === 'interactive' ? 'text-indigo-600' : 'hover:text-slate-900'} transition flex items-center gap-1.5`}>
            {t('navInteractive')}
          </button>
        </nav>
        
        <div className="flex items-center gap-4">
          <select value={currentLang} onChange={(e) => setCurrentLang(e.target.value as Language)} className="hidden sm:block bg-slate-50 border border-slate-200 text-slate-700 text-xs font-medium rounded-md px-2 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer">
            <option value="en">English</option>
            <option value="hi">हिन्दी (Hindi)</option>
            <option value="ra">राजस्थानी (Marwari)</option>
          </select>

          {!isLoggedIn ? (
            <button onClick={() => setCurrentPage('login')} className="px-5 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-lg shadow-sm hover:bg-indigo-700 transition">{t('navLogin')}</button>
          ) : (
            <span className="px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-full flex items-center gap-1.5 shadow-sm">
              <Crown className="w-3.5 h-3.5" /> Maharaja Guest
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
