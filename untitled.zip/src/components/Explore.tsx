import { Map } from 'lucide-react';
import React, { useState } from 'react';
import { vectorMapNodes } from '../data';

export default function Explore({ destinations, toggleMapCity }: { destinations: string[], toggleMapCity: (c: string) => void }) {
  const hasCity = (cityName: string) => destinations.includes(cityName);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12 animate-in fade-in duration-500">
      
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <h2 className="text-4xl text-slate-900 font-extrabold tracking-tight">Heritage, Craftsmanship & Cuisine</h2>
        <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Immerse your senses in royal Rajasthani legacy</p>
        <div className="h-[2px] w-24 bg-indigo-600 mx-auto mt-4 rounded-full"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl overflow-hidden border border-slate-200 group hover:border-indigo-300 hover:shadow-lg transition duration-300">
          <div className="relative h-48 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=500&q=80" loading="lazy" className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition duration-500" alt="Culture" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
          </div>
          <div className="p-6 space-y-3">
            <h3 className="text-lg font-bold text-slate-800">Folk Dances & Arts</h3>
            <p className="text-slate-600 text-sm leading-relaxed">Experience Ghoomar, Kalbelia (Snake dance), and ancient Kathputli string puppetry.</p>
            <div className="flex flex-wrap gap-2 pt-2">
              {['Ghoomar','Kalbelia','Chari Dance','Kathputli'].map(c => <span key={c} className="bg-slate-50 border border-slate-200 font-medium text-[11px] text-slate-600 px-2.5 py-1 rounded-full">{c}</span>)}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl overflow-hidden border border-slate-200 group hover:border-indigo-300 hover:shadow-lg transition duration-300">
          <div className="relative h-48 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&w=500&q=80" loading="lazy" className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition duration-500" alt="Handicrafts" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
          </div>
          <div className="p-6 space-y-3">
            <h3 className="text-lg font-bold text-slate-800">Imperial Handicrafts</h3>
            <p className="text-slate-600 text-sm leading-relaxed">Shop block-print textiles, blue-glazed pottery of Jaipur, and fine gold jewelry.</p>
            <div className="flex flex-wrap gap-2 pt-2">
              {['Block Print','Blue Pottery','Meenakari','Metal Crafts'].map(h => <span key={h} className="bg-slate-50 border border-slate-200 font-medium text-[11px] text-slate-600 px-2.5 py-1 rounded-full">{h}</span>)}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl overflow-hidden border border-slate-200 group hover:border-indigo-300 hover:shadow-lg transition duration-300">
          <div className="relative h-48 overflow-hidden">
            <img src="https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=500&q=80" loading="lazy" className="w-full h-full object-cover opacity-90 group-hover:scale-105 transition duration-500" alt="Food" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
          </div>
          <div className="p-6 space-y-3">
            <h3 className="text-lg font-bold text-slate-800">Gastronomic Kingdom</h3>
            <p className="text-slate-600 text-sm leading-relaxed">Feast on spicy Dal Baati Churma, slow-cooked Laal Maas, and decadent sweet Ghewar.</p>
            <div className="flex flex-wrap gap-2 pt-2">
              {['Dal Baati Churma','Laal Maas','Ghewar','Ker Sangri'].map(f => <span key={f} className="bg-slate-50 border border-slate-200 font-medium text-[11px] text-slate-600 px-2.5 py-1 rounded-full">{f}</span>)}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
              <Map className="w-6 h-6" />
            </div>
            <h3 className="text-2xl text-slate-900 font-bold tracking-tight">
              Interactive Caravan Planner
            </h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Click on the points on the map coordinate grid to automatically toggle cities in your travel plan. The connected route plots itself!
            </p>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 mt-4">
              <p className="text-indigo-600 font-bold uppercase tracking-widest text-[10px]">Active Route Segment String:</p>
              <p className="text-slate-700 text-sm font-medium">
                {destinations.join(' ➔ ') || 'No cities selected yet. Touch a city on map grid to begin.'}
              </p>
            </div>
          </div>

          <div className="lg:col-span-2 relative bg-slate-50 border border-slate-200 rounded-2xl p-4 overflow-hidden h-[400px]">
            <svg className="w-full h-full" viewBox="0 0 500 400" xmlns="http://www.w3.org/2000/svg">
              <pattern id="geoGrid" width="25" height="25" patternUnits="userSpaceOnUse">
                <path d="M 25 0 L 0 0 0 25" fill="none" stroke="#e2e8f0" strokeOpacity="1" strokeWidth="1"/>
              </pattern>
              <rect width="500" height="400" fill="url(#geoGrid)" />

              <polygon points="120,80 180,60 260,70 320,50 380,80 420,130 450,210 400,280 340,320 280,350 200,340 130,290 80,240 60,160" fill="none" stroke="#cbd5e1" strokeWidth="2" strokeDasharray="6 6" opacity="0.6" />

              {destinations.length > 1 && (
                <g stroke="#6366f1" strokeWidth="3" strokeDasharray="6 6">
                  {hasCity('Jaipur') && hasCity('Jodhpur') && <line x1="320" y1="160" x2="230" y2="180" className="animate-pulse" />}
                  {hasCity('Jodhpur') && hasCity('Jaisalmer') && <line x1="230" y1="180" x2="110" y2="190" className="animate-pulse" />}
                  {hasCity('Jodhpur') && hasCity('Udaipur') && <line x1="230" y1="180" x2="210" y2="290" className="animate-pulse" />}
                  {hasCity('Jaipur') && hasCity('Udaipur') && <line x1="320" y1="160" x2="210" y2="290" className="animate-pulse" />}
                  {hasCity('Jaipur') && hasCity('Pushkar') && <line x1="320" y1="160" x2="280" y2="175" className="animate-pulse" />}
                  {hasCity('Pushkar') && hasCity('Jodhpur') && <line x1="280" y1="175" x2="230" y2="180" className="animate-pulse" />}
                </g>
              )}

              {vectorMapNodes.map(node => (
                <g key={node.name} className="cursor-pointer group" onClick={() => toggleMapCity(node.name)}>
                  {hasCity(node.name) && (
                    <circle cx={node.x} cy={node.y} r="16" fill="none" stroke="#6366f1" strokeWidth="2" className="animate-ping" opacity="0.4" />
                  )}
                  <circle cx={node.x} cy={node.y} r={hasCity(node.name) ? "8" : "6"} fill={hasCity(node.name) ? '#4f46e5' : '#cbd5e1'} stroke="#ffffff" strokeWidth="2" className="shadow-sm" />
                  <text x={node.x} y={node.y - 14} textAnchor="middle" className="text-[11px] fill-slate-700 font-bold select-none group-hover:fill-indigo-600 transition duration-200 drop-shadow-sm">
                    {node.name}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}
