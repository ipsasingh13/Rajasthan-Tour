import {
  ArrowRight, Calculator,
  CalendarDays,
  ChartPie, ChevronRight,
  Clock,
  CloudRain,
  Coins,
  Copy, Hotel,
  Info, Leaf,
  MapPin,
  PlaneTakeoff,
  Printer,
  Route,
  Settings,
  Sparkles,
  Briefcase,
  Users
} from 'lucide-react';
import React, { useMemo, useState, useEffect } from 'react';
import { attractionsData, budgetRows, cityDaysDatabase, destinationsList, translations, weatherDatabase } from '../data';
import { Language, PlannerForm } from '../types';

export default function Planner({ currentLang, addToast, openAttractionDetail }: { currentLang: Language, addToast: (msg: string) => void, openAttractionDetail: (name: string, cat: string) => void }) {
  const t = (key: string) => translations[currentLang][key] || translations['en'][key];
  
  const [plannerStep, setPlannerStep] = useState(1);
  const [form, setForm] = useState<PlannerForm>({
    destinations: ['Jaipur', 'Jodhpur'],
    days: '5 Days',
    people: 'Family',
    categories: ['Historical Tourism', 'Cultural Tourism'],
    accommodation: 'Heritage Palace',
    transport: 'Car Rental'
  });

  const changePlannerStep = (step: number) => {
    setPlannerStep(step);
    addToast(`Navigating to Step: ${step}`);
  };

  const handleDestChange = (dest: string) => {
    setForm(prev => {
      if (prev.destinations.includes(dest)) {
        return { ...prev, destinations: prev.destinations.filter(d => d !== dest) };
      } else {
        return { ...prev, destinations: [...prev.destinations, dest] };
      }
    });
  };

  const handleCatChange = (cat: string) => {
    setForm(prev => {
      if (prev.categories.includes(cat)) {
        return { ...prev, categories: prev.categories.filter(c => c !== cat) };
      } else {
        return { ...prev, categories: [...prev.categories, cat] };
      }
    });
  };

  // Step 3 Itinerary computation
  const computedItinerary = useMemo(() => {
    const selectedCities = form.destinations;
    const activeCities = selectedCities.length > 0 ? selectedCities : ['Jaipur'];
    const totalDaysNum = parseInt(form.days) || 3;
    
    const daysPerCity = Math.floor(totalDaysNum / activeCities.length);
    let remainderDays = totalDaysNum % activeCities.length;
    
    const cityAllocations: Record<string, number> = {};
    activeCities.forEach((city) => {
      cityAllocations[city] = daysPerCity + (remainderDays > 0 ? 1 : 0);
      remainderDays--;
    });

    const finalItinerary = [];
    let currentDayCounter = 1;

    activeCities.forEach((city) => {
      const daysToGenerate = cityAllocations[city] || 1;
      const dbTemplates = cityDaysDatabase[city] || [
        { title: `${city} Heritage Explorer`, spots: [`${city} Royal Fort`, `${city} Traditional Bazaar`], time: "09:00 AM - 06:00 PM" }
      ];

      for (let d = 0; d < daysToGenerate; d++) {
        if (d < dbTemplates.length) {
          const dayBlueprint = dbTemplates[d];
          finalItinerary.push({
            dayNum: currentDayCounter,
            city: city,
            title: dayBlueprint.title,
            spots: dayBlueprint.spots,
            time: dayBlueprint.time
          });
        } else {
          finalItinerary.push({
            dayNum: currentDayCounter,
            city: city,
            title: `${city} Leisure & Cultural Bazaar Immersion`,
            spots: [`${city} Traditional Crafts Block`, `${city} Food Gastronomy Stalls`],
            time: "10:00 AM - 08:30 PM"
          });
        }
        currentDayCounter++;
      }
    });

    return finalItinerary;
  }, [form.destinations, form.days]);

  const copyItineraryToClipboard = () => {
    let formatted = "👑 RAJASTHAN ROYAL EXPLORER PLAN 👑\n\n";
    computedItinerary.forEach(day => {
      formatted += `Day ${day.dayNum} - ${day.city}: ${day.title}\nSpots: ${day.spots.join(', ')}\n\n`;
    });
    
    navigator.clipboard.writeText(formatted).then(() => {
      addToast("Itinerary copied to clipboard successfully!");
    });
  };

  const printItinerary = () => {
    window.print();
  };

  const filteredAttractionsData = useMemo(() => {
    const currentDestinations = form.destinations.length > 0 ? form.destinations : ['Jaipur'];
    const validSpots = new Set<string>();
    currentDestinations.forEach(city => {
      const days = cityDaysDatabase[city] || [];
      days.forEach(day => {
        day.spots.forEach((spot: string) => validSpots.add(spot));
      });
    });

    const result: Record<string, string[]> = {};
    Object.entries(attractionsData).forEach(([category, items]) => {
      const filteredItems = items.filter(item => validSpots.has(item) || category === 'Famous Food');
      if (filteredItems.length > 0) {
        result[category] = filteredItems;
      }
    });
    return result;
  }, [form.destinations]);

  // Budget
  const [budgetInput, setBudgetInput] = useState(45000);
  const [budgetPeople, setBudgetPeople] = useState(3);
  const [budgetDays, setBudgetDays] = useState(5);

  const calculatedTotal = budgetPeople * budgetDays * 2200;
  const budgetMeterPercent = Math.min(Math.max((calculatedTotal / budgetInput) * 100, 15), 100);
  const budgetMeterStatus = budgetMeterPercent < 55 ? "Under Budget Target" : budgetMeterPercent < 85 ? "Approaching Limit" : "Target Exceeded!";
  const budgetMeterClass = budgetMeterPercent < 55 ? "bg-emerald-500" : budgetMeterPercent < 85 ? "bg-amber-500" : "bg-rose-600";
  const budgetMeterTextClass = budgetMeterPercent < 55 ? "text-emerald-400" : budgetMeterPercent < 85 ? "text-amber-400" : "text-rose-400";

  // Weather
  const [selectedWeatherCity, setSelectedWeatherCity] = useState('Jaipur');
  const [liveWeather, setLiveWeather] = useState({ temp: '32', rain: '10', wind: '12' });

  useEffect(() => {
    const databaseMetrics = weatherDatabase[selectedWeatherCity];
    if (databaseMetrics) {
      setLiveWeather({
        temp: databaseMetrics.temp,
        rain: databaseMetrics.rain,
        wind: databaseMetrics.wind
      });
    }
  }, [selectedWeatherCity]);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 animate-in fade-in duration-500">
      
      {/* Wizard Step Navigation */}
      <div className="flex justify-center mb-8 border-b border-slate-200 pb-4 overflow-x-auto space-x-2 sm:space-x-8">
        {[1,2,3,4,5].map(step => (
          <button 
            key={step} 
            onClick={() => setPlannerStep(step)} 
            className={`pb-2 text-xs sm:text-sm uppercase tracking-widest whitespace-nowrap transition-colors ${plannerStep === step ? 'text-indigo-600 border-b-2 border-indigo-600 font-bold' : 'text-slate-500 hover:text-slate-700'}`}
          >
            {step === 1 ? t('step1') : step === 2 ? t('step2') : step === 3 ? t('step3') : step === 4 ? t('step4') : 'Smart Checklist'}
          </button>
        ))}
      </div>

      {/* STEP 1: TRAVEL PREFERENCES */}
      {plannerStep === 1 && (
        <div className="bg-white border border-slate-200 shadow-sm p-6 rounded-xl space-y-8 animate-in slide-in-from-right-8 duration-500">
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-indigo-600" /> {t('prefWhere')}
            </h3>
            <p className="text-slate-500 text-xs mb-3">Choose any combinations of destinations. Proximity paths will build themselves!</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
              {destinationsList.map(dest => (
                <label key={dest} className="flex items-center space-x-2 bg-slate-50 p-3 rounded-lg border border-slate-200 cursor-pointer hover:border-indigo-300 hover:bg-slate-100 transition duration-200">
                  <input type="checkbox" checked={form.destinations.includes(dest)} onChange={() => handleDestChange(dest)} className="accent-indigo-600 w-4 h-4" />
                  <span className="text-xs text-slate-700 font-medium">{dest}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center"><CalendarDays className="mr-2 w-5 h-5 text-indigo-600" /> {t('prefDays')}</h3>
              <select value={form.days} onChange={e => setForm({...form, days: e.target.value})} className="w-full bg-slate-50 border border-slate-200 text-slate-700 p-3 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                {['1 Day','3 Days','5 Days','7 Days','10 Days','15 Days'].map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center"><Users className="mr-2 w-5 h-5 text-indigo-600" /> {t('prefPeople')}</h3>
              <select value={form.people} onChange={e => setForm({...form, people: e.target.value})} className="w-full bg-slate-50 border border-slate-200 text-slate-700 p-3 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                {['Solo','Couple','Family','Friends Group','Corporate Group'].map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center"><Hotel className="mr-2 w-5 h-5 text-indigo-600" /> {t('prefHotel')}</h3>
              <div className="grid grid-cols-2 gap-2">
                {['Budget','Standard','Luxury','Heritage Palace'].map(acc => (
                  <label key={acc} className="flex items-center space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs cursor-pointer hover:border-indigo-300 transition">
                    <input type="radio" name="accommodation" value={acc} checked={form.accommodation === acc} onChange={() => setForm({...form, accommodation: acc})} className="accent-indigo-600 w-4 h-4" />
                    <span className="text-slate-700">{acc}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center"><Sparkles className="mr-2 w-5 h-5 text-indigo-600" /> {t('prefCategories')}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {['Historical Tourism','Religious Tourism','Wildlife Tourism','Luxury Tourism','Adventure Tourism','Village Tourism','Cultural Tourism','Photography Tourism','Honeymoon Tourism','Food Tourism'].map(cat => (
                <label key={cat} className="flex items-center space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs cursor-pointer hover:border-indigo-300 transition">
                  <input type="checkbox" checked={form.categories.includes(cat)} onChange={() => handleCatChange(cat)} className="accent-indigo-600 w-4 h-4" />
                  <span className="text-slate-700">{cat}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center"><PlaneTakeoff className="mr-2 w-5 h-5 text-indigo-600" /> {t('prefTransport')}</h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {['Bus','Train','Car Rental','Self Drive','Flight'].map(trans => (
                <label key={trans} className="flex items-center space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs cursor-pointer hover:border-indigo-300 transition">
                  <input type="radio" name="transport" value={trans} checked={form.transport === trans} onChange={() => setForm({...form, transport: trans})} className="accent-indigo-600 w-4 h-4" />
                  <span className="text-slate-700">{trans}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-200">
            <button onClick={() => changePlannerStep(2)} className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-8 py-3 rounded-lg text-xs uppercase tracking-widest shadow-md hover:shadow-lg hover:-translate-y-0.5 transition-all flex items-center">
              {t('btnNextPlaces')} <ArrowRight className="ml-2 w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: SIGHTSEEING SELECTION */}
      {plannerStep === 2 && (
        <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
          <div className="bg-white border border-slate-200 shadow-sm p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
            <div>
              <p className="text-xs text-slate-500">{t('currentPrefFilter')}</p>
              <p className="text-sm text-slate-700">
                Destinations Chosen: <span className="font-semibold text-indigo-600">{form.destinations.join(', ') || 'Jaipur'}</span>
              </p>
            </div>
            <button onClick={() => changePlannerStep(3)} className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-lg text-xs uppercase tracking-widest flex items-center gap-1.5 shadow-md hover:-translate-y-0.5 transition-all">
              {t('btnGenItinerary')} <Settings className="w-4 h-4" />
            </button>
          </div>

          <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-lg text-xs text-indigo-800 flex items-start gap-3 shadow-sm">
            <Info className="text-indigo-600 w-4 h-4 mt-0.5 shrink-0" />
            <div>
              <strong>💡 Secret Guides:</strong> Click on any attraction listed below to read an immersive synopsis, exact timing directories, and localized recommendations.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Object.entries(filteredAttractionsData).length > 0 ? (
              Object.entries(filteredAttractionsData).map(([category, items]) => (
                <div key={category} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
                  <h4 className="font-semibold text-md text-slate-900 border-b border-slate-100 pb-2 mb-3 flex justify-between items-center">
                    <span>{category}</span>
                    <span className="text-[9px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded font-semibold tracking-wider uppercase">Info Included</span>
                  </h4>
                  <ul className="space-y-2">
                    {(items as string[]).map((item: string) => (
                      <li key={item} onClick={() => openAttractionDetail(item, category)} className="text-xs bg-slate-50 p-3 rounded-lg border border-slate-200 hover:border-indigo-300 hover:shadow-sm cursor-pointer flex items-center justify-between transition-all hover:-translate-y-0.5 duration-200 group">
                        <span className="text-slate-700 group-hover:text-indigo-600 flex items-center"><MapPin className="text-indigo-500 mr-2 w-3 h-3" />{item}</span>
                        <span className="text-[9px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded border border-slate-300 font-medium flex items-center group-hover:bg-indigo-100 group-hover:text-indigo-700 group-hover:border-indigo-200 transition-colors"><Info className="mr-1 w-3 h-3" />Explore</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))
            ) : (
              <div className="col-span-full p-8 text-center text-slate-500 bg-slate-50 rounded-xl border border-slate-200 border-dashed">
                No major tracked sightseeing spots in the current selected route.
              </div>
            )}
          </div>
        </div>
      )}

      {/* STEP 3: CUSTOMIZABLE SMART ITINERARY */}
      {plannerStep === 3 && (
        <div className="space-y-6 animate-in slide-in-from-right-8 duration-500">
          <div className="bg-white border border-slate-200 shadow-sm p-6 rounded-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-1 flex items-center"><Sparkles className="mr-2 w-5 h-5 text-indigo-600" /> {t('itineraryTitle')}</h3>
              <p className="text-xs text-slate-500">
                Customized multi-destination itinerary created for <span className="text-indigo-600 font-bold">{form.destinations.join(' ➔ ') || 'Jaipur'}</span> spanning <span className="text-slate-900 underline font-semibold">{form.days}</span>.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button onClick={printItinerary} className="bg-white border border-slate-300 hover:bg-slate-50 hover:border-slate-400 text-slate-700 font-semibold px-4 py-2 rounded-lg text-xs flex items-center gap-1 transition-colors shadow-sm">
                <Printer className="text-slate-500 w-4 h-4" /> Print / Save
              </button>
              <button onClick={copyItineraryToClipboard} className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded-lg text-xs flex items-center gap-1 transition-colors shadow-sm">
                <Copy className="w-4 h-4" /> Copy Plan
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              {computedItinerary.map((day) => (
                <div key={day.dayNum} className="bg-white p-5 rounded-xl border border-slate-200 relative shadow-sm">
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-600 rounded-l-xl"></div>
                  <div className="flex flex-wrap justify-between items-start mb-3 pl-2">
                    <div>
                      <span className="text-xs font-bold text-indigo-600 tracking-widest uppercase">Day {day.dayNum}</span>
                      <h4 className="text-lg font-semibold text-slate-900">{day.city} — {day.title}</h4>
                    </div>
                    <span className="text-xs bg-slate-100 text-slate-700 px-3 py-1 rounded-full border border-slate-200 mt-1 sm:mt-0 flex items-center"><Clock className="mr-1 w-3 h-3 text-indigo-600" /> {day.time}</span>
                  </div>
                  
                  <p className="text-xs text-slate-500 mb-3 font-medium pl-2">Recommended activities based on travel categories and seasons:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-2">
                    {day.spots.map((spot) => (
                      <div key={spot} onClick={() => openAttractionDetail(spot, day.city + ' Sightseeing')} className="bg-slate-50 p-3 rounded-lg border border-slate-200 hover:border-indigo-300 hover:bg-slate-100 cursor-pointer text-xs text-slate-700 flex items-center justify-between group transition">
                        <span className="flex items-center gap-2">
                          <MapPin className="text-indigo-400 group-hover:text-indigo-600 transition w-4 h-4" /> 
                          {spot}
                        </span>
                        <ChevronRight className="text-slate-400 group-hover:text-indigo-600 w-4 h-4 transform group-hover:translate-x-1 transition" />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
                <h4 className="text-md font-semibold text-slate-900 flex items-center"><Route className="mr-2 w-4 h-4 text-indigo-600" /> Route Insights</h4>
                <div className="space-y-3 text-xs">
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <p className="text-slate-500">Total Route sequence:</p>
                    <p className="text-indigo-700 font-semibold text-xs mt-1">
                      {form.destinations.join(' ➔ ') || 'Jaipur City Region'}
                    </p>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 flex justify-between">
                    <span className="text-slate-500">Est. Travel Time:</span>
                    <span className="text-slate-900 font-mono font-medium">{(form.destinations.length * 2.5 + 1.5).toFixed(1)} Hours</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 flex justify-between items-center">
                    <span className="text-slate-500">Pace:</span>
                    <span className="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded font-bold uppercase tracking-wider text-[10px]">Balanced</span>
                  </div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <h4 className="text-md font-semibold text-slate-900 flex items-center"><Hotel className="mr-2 w-4 h-4 text-indigo-600" /> Selected Stays</h4>
                <div className="space-y-2 text-xs">
                  {(form.destinations.length > 0 ? form.destinations : ['Jaipur']).map((city) => (
                    <div key={city} className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <p className="font-semibold text-slate-800 flex items-center"><Hotel className="text-indigo-500 mr-1.5 w-3 h-3" /> {city} {form.accommodation} Stay</p>
                      <p className="text-[10px] text-slate-500 font-medium mt-0.5">Optimized placement near historic center monuments.</p>
                    </div>
                  ))}
                </div>
              </div>
              <button onClick={() => changePlannerStep(4)} className="w-full bg-indigo-600 text-white font-semibold py-3.5 rounded-lg text-xs uppercase tracking-widest flex items-center justify-center gap-1.5 shadow-md hover:bg-indigo-700 hover:-translate-y-0.5 transition-all">
                Proceed to Budgets & Weather <Calculator className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 4: BUDGETS & WEATHER METRICS */}
      {plannerStep === 4 && (
        <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
              <h4 className="text-lg font-semibold text-slate-900 flex items-center"><Coins className="mr-2 w-5 h-5 text-indigo-600" /> Smart Budget Calculator</h4>
              <div>
                <label className="text-xs text-slate-500 block mb-1">Target Budget Limit (₹)</label>
                <input type="number" value={budgetInput} onChange={e => setBudgetInput(Number(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Total Travelers</label>
                  <input type="number" value={budgetPeople} onChange={e => setBudgetPeople(Number(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
                <div>
                  <label className="text-xs text-slate-500 block mb-1">Travel Days</label>
                  <input type="number" value={budgetDays} onChange={e => setBudgetDays(Number(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200">
                <span className="text-xs text-slate-500 block mb-1 font-semibold uppercase tracking-wider">Budget Status Meter</span>
                <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden flex">
                  <div className={`${budgetMeterClass === 'bg-emerald-500' ? 'bg-emerald-500' : budgetMeterClass === 'bg-amber-500' ? 'bg-amber-500' : 'bg-rose-500'} h-full transition-all duration-500`} style={{ width: `${budgetMeterPercent}%` }}></div>
                </div>
                <div className="flex justify-between text-[11px] mt-1.5">
                  <span className={`font-bold uppercase tracking-wider ${budgetMeterTextClass === 'text-emerald-400' ? 'text-emerald-600' : budgetMeterTextClass === 'text-amber-400' ? 'text-amber-600' : 'text-rose-600'}`}>{budgetMeterStatus}</span>
                  <span className="text-slate-500 font-mono font-medium">Est: ₹{calculatedTotal}</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm md:col-span-2 space-y-3">
              <h4 className="text-lg font-semibold text-slate-900 mb-3 flex items-center"><ChartPie className="mr-2 w-5 h-5 text-indigo-600" /> Dynamic Expense Breakdown</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 uppercase tracking-widest text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-3 font-semibold">Expense Category</th>
                      <th className="p-3 font-semibold">Projected Ratio</th>
                      <th className="p-3 text-right font-semibold">Projected Value</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {budgetRows.map((row) => (
                      <tr key={row.cat}>
                        <td className="p-3 text-slate-700 font-medium">{row.cat}</td>
                        <td className="p-3 text-slate-500">{row.ratio}</td>
                        <td className="p-3 text-right font-mono text-indigo-700 font-medium">₹{Math.round(budgetInput * row.multiplier)}</td>
                      </tr>
                    ))}
                    <tr className="bg-slate-50 font-bold border-t border-slate-200">
                      <td className="p-3 text-slate-900 text-sm" colSpan={2}>TOTAL TARGET SPECIFIED</td>
                      <td className="p-3 text-right font-mono text-indigo-700 text-sm">₹{budgetInput}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-md font-semibold text-slate-900 flex items-center"><CloudRain className="mr-2 w-4 h-4 text-indigo-600" /> Meteorological Dashboard</h4>
                <div className="flex items-center gap-2">
                  <label className="text-[10px] text-slate-500 uppercase">Target City:</label>
                  <select value={selectedWeatherCity} onChange={e => setSelectedWeatherCity(e.target.value)} className="bg-slate-50 border border-slate-200 text-xs text-slate-900 rounded p-1.5 focus:outline-none focus:ring-1 focus:ring-indigo-500">
                    {destinationsList.map(city => <option key={city} value={city}>{city}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 text-center text-xs">
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block mb-1">Temperature</span>
                  <span className="text-xl text-indigo-600 font-mono font-bold">{liveWeather.temp}°C</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block mb-1">Chance of Rain</span>
                  <span className="text-xl text-blue-600 font-mono font-bold">{liveWeather.rain}%</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
                  <span className="text-slate-500 block mb-1">Wind Speed</span>
                  <span className="text-xl text-slate-700 font-mono font-bold">{liveWeather.wind} km/h</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
              <h4 className="text-md font-semibold text-slate-900 mb-3 flex items-center"><Leaf className="mr-2 w-4 h-4 text-indigo-600" /> Season Advisory Details</h4>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center bg-emerald-50 p-3 rounded-lg border border-emerald-100">
                  <span className="text-emerald-900">October - February (Winter)</span>
                  <span className="text-emerald-700 font-bold uppercase text-[9px] tracking-wider">Perfect Climate</span>
                </div>
                <div className="flex justify-between items-center bg-amber-50 p-3 rounded-lg border border-amber-100">
                  <span className="text-amber-900">March - June (Summer)</span>
                  <span className="text-amber-700 font-bold uppercase text-[9px] tracking-wider">Hot Dry Climate</span>
                </div>
                <div className="flex justify-between items-center bg-sky-50 p-3 rounded-lg border border-sky-100">
                  <span className="text-sky-900">July - September (Monsoon)</span>
                  <span className="text-sky-700 font-bold uppercase text-[9px] tracking-wider">Great For Lakes</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STEP 5: INTELLIGENT PACKING CHECKLIST */}
      {plannerStep === 5 && (
        <div className="bg-white border border-slate-200 shadow-sm p-6 rounded-xl space-y-6 animate-in slide-in-from-right-8 duration-500">
          <div className="text-center max-w-xl mx-auto space-y-2">
            <h3 className="text-2xl font-bold text-slate-900 flex items-center justify-center"><Briefcase className="mr-2 w-6 h-6 text-indigo-600" /> Smart Packing checklist</h3>
            <p className="text-slate-500 text-xs">A dynamically suggested packaging list configured automatically for your destination parameters.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
            {[
              { title: "🛡 Protection Essentials", items: ["SPF 50 Sunscreen Cream", "UV Polarized Sunglasses", "Hydration Water Flask"] },
              { title: "👗 Clothing Guidelines", items: ["Light breathable cotton apparel", "Elegant scarves for temple visits", "Walking slip-on shoes"] },
              { title: "📸 Documentation & Tech", items: ["Mobile charger power-bank", "Heritage guide PDF downloads", "National Identity documents"] }
            ].map(section => (
              <div key={section.title} className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-3">
                <h4 className="text-sm font-semibold text-indigo-700 border-b border-slate-200 pb-2">
                  {section.title}
                </h4>
                <ul className="space-y-2">
                  {section.items.map(item => (
                    <li key={item} className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer hover:text-indigo-600 transition-colors">
                      <input type="checkbox" className="accent-indigo-600 w-4 h-4 cursor-pointer" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
