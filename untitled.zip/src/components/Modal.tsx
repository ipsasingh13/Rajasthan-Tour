import {
  X
} from 'lucide-react';
import React from 'react';
import { ModalData } from '../types';

export default function Modal({ modalData, showModal, setShowModal }: { modalData: ModalData | null, showModal: boolean, setShowModal: (v: boolean) => void }) {
  if (!showModal || !modalData) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl relative">
        <div className="h-48 w-full relative overflow-hidden">
          <img src={modalData.image} loading="lazy" alt={modalData.name} className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent"></div>
          <span className="absolute top-4 left-4 bg-indigo-600 text-white font-bold text-xs px-3 py-1.5 rounded-md uppercase tracking-wider shadow">
            {modalData.category}
          </span>
          <button onClick={() => setShowModal(false)} className="absolute top-4 right-4 bg-white/20 backdrop-blur-md text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-white hover:text-slate-900 transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          <div>
            <h3 className="text-2xl text-slate-900 font-extrabold tracking-tight">{modalData.name}</h3>
            <p className="text-xs text-indigo-600 font-bold uppercase tracking-wider mt-1">Rajasthan Heritage Directory Guide</p>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed">
            {modalData.description}
          </p>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100 text-xs font-semibold">
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block mb-1 uppercase tracking-wider text-[10px]">⏰ Visiting Hours</span>
              <span className="text-slate-800">{modalData.timings}</span>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-slate-400 block mb-1 uppercase tracking-wider text-[10px]">🎟 Entry Fees</span>
              <span className="text-slate-800">{modalData.fee}</span>
            </div>
            <div className="bg-indigo-50 p-3 rounded-xl border border-indigo-100 col-span-2 text-xs">
              <span className="text-indigo-600 font-bold block uppercase tracking-wider text-[10px] mb-1">💡 Insider Travel Advice</span>
              <span className="text-indigo-900 font-medium">{modalData.tip}</span>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end rounded-b-2xl">
          <button onClick={() => setShowModal(false)} className="bg-indigo-600 text-white font-semibold px-6 py-2.5 rounded-lg text-sm shadow-sm hover:bg-indigo-700 transition">
            Acknowledge Guide
          </button>
        </div>
      </div>
    </div>
  );
}
