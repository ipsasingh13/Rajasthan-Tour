import { Copy, Guitar, MailOpen } from 'lucide-react';
import React, { useState } from 'react';
import * as Tone from 'tone';

export default function Interactive({ addToast }: { addToast: (msg: string) => void }) {
  const sitarStrings = [
    { id: 1, freq: 261.63, note: "Sa (C4)" },
    { id: 2, freq: 293.66, note: "Re (D4)" },
    { id: 3, freq: 329.63, note: "Ga (E4)" },
    { id: 4, freq: 349.23, note: "Ma (F4)" },
    { id: 5, freq: 392.00, note: "Pa (G4)" },
    { id: 6, freq: 440.00, note: "Dha (A4)" }
  ];

  const [cardMessage, setCardMessage] = useState('');
  const [cardSignature, setCardSignature] = useState('');

  const triggerString = async (freq: number) => {
    try {
      await Tone.start();
      const synth = new Tone.Synth({
        oscillator: { type: "triangle" },
        envelope: { attack: 0.1, decay: 0.8, sustain: 0.1, release: 1.2 }
      }).toDestination();
      
      synth.volume.value = -12; // safe volume
      synth.triggerAttackRelease(freq, "8n");
      // addToast(`Strummed Sitar frequency: ${freq} Hz`);
    } catch (e) {
      console.warn("Acoustic audio initialization failed or needs interaction.");
    }
  };

  const copyPostcardText = () => {
    const textToCopy = `Postcard Greeting from Rajasthan!\n\nMessage: ${cardMessage || 'Hello from the sand dunes!'}\nSignature: ${cardSignature || 'Your Maharaja Friend'}`;
    navigator.clipboard.writeText(textToCopy).then(() => {
      addToast("Postcard copied to your clipboard!");
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-12 animate-in fade-in duration-500">
      <div className="text-center max-w-xl mx-auto space-y-2">
        <h2 className="font-bold text-3xl text-slate-900">The Sensory Chamber</h2>
        <p className="text-xs text-slate-500 uppercase tracking-widest font-medium">Connect with ancient acoustic strings and crafts</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Virtual Sitar */}
        <div className="bg-white border border-slate-200 shadow-sm p-6 rounded-xl flex flex-col justify-between">
          <div className="space-y-2">
            <h3 className="font-bold text-xl text-slate-900 flex items-center"><Guitar className="mr-2 w-5 h-5 text-indigo-600" /> Virtual Indian Classical Sitar</h3>
            <p className="text-xs text-slate-500">Click or hover-drag over the strings below to strum synthesized in real-time via WebAudio.</p>
          </div>

          <div className="relative bg-slate-50 h-56 rounded-lg border border-slate-200 my-6 flex flex-col justify-around p-4 overflow-hidden">
            <div className="absolute right-6 top-1/2 -translate-y-1/2 w-28 h-28 bg-slate-100 rounded-full border border-slate-200 flex items-center justify-center">
              <div className="w-16 h-16 bg-slate-800 rounded-full border-2 border-slate-300 shadow-inner"></div>
            </div>

            {sitarStrings.map(string => (
              <div 
                key={string.id}
                onMouseEnter={() => triggerString(string.freq)}
                onMouseDown={() => triggerString(string.freq)}
                className="w-full h-1 cursor-pointer relative transition-transform active:scale-y-150"
                style={{ backgroundColor: `rgba(79, 70, 229, ${0.4 + (string.id * 0.1)})` }}
              >
                <div className="absolute -top-1 left-4 bg-slate-50 px-1 text-[8px] text-slate-500 uppercase tracking-widest font-mono rounded">
                  String {string.id} - {string.note}
                </div>
              </div>
            ))}
          </div>

          <div className="text-[10px] text-slate-500 text-center font-medium">
            Note: Generates beautiful real-time sound frequencies using the Web Audio API. Enable your system sound!
          </div>
        </div>

        {/* Postcard */}
        <div className="bg-white border border-slate-200 shadow-sm p-6 rounded-xl flex flex-col justify-between">
          <div className="space-y-2">
            <h3 className="font-bold text-xl text-slate-900 flex items-center"><MailOpen className="mr-2 w-5 h-5 text-indigo-600" /> Design your Postcard</h3>
            <p className="text-xs text-slate-500">Compose customized messages inside a digital postcard to share with friends.</p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-6 my-6 rounded-lg relative overflow-hidden shadow-inner">
            <div className="absolute inset-2 border border-slate-200 bg-white shadow-sm rounded-sm"></div>
            
            <div className="relative z-10 flex flex-col justify-between h-44 p-2">
              <div className="flex justify-between items-start">
                <div>
                  <span className="font-bold text-slate-800 text-sm tracking-widest">KHAMMA GHANI</span>
                  <p className="text-[9px] text-slate-500 uppercase tracking-wider font-medium">From Rajasthan</p>
                </div>
                <div className="w-10 h-12 bg-indigo-50 border border-indigo-100 flex flex-col items-center justify-center p-1 rounded shadow-sm">
                  <span className="text-[6px] text-indigo-600 uppercase font-mono font-bold">Postage</span>
                  <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1 animate-pulse"></div>
                </div>
              </div>

              <div className="my-3 text-center">
                <p className="text-sm text-slate-700 italic font-serif">"{cardMessage || 'Write your message inside the fields below...'}"</p>
              </div>

              <div className="flex justify-between items-end border-t border-slate-100 pt-2">
                <span className="text-[10px] text-slate-500 tracking-widest uppercase font-medium">Signature: <span className="text-indigo-600 font-semibold">{cardSignature || 'Your Friend'}</span></span>
                <span className="text-[9px] text-slate-400 font-mono">RAJS-7451-2026</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-widest block mb-1 font-medium">Type Card Message</label>
                <input type="text" value={cardMessage} onChange={e => setCardMessage(e.target.value)} className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-xs rounded p-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
              </div>
              <div>
                <label className="text-[10px] text-slate-500 uppercase tracking-widest block mb-1 font-medium">Your Signature Name</label>
                <input type="text" value={cardSignature} onChange={e => setCardSignature(e.target.value)} className="w-full bg-slate-50 border border-slate-200 text-slate-900 text-xs rounded p-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
              </div>
            </div>
            <button onClick={copyPostcardText} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs py-2.5 rounded-lg uppercase tracking-wider font-bold transition flex items-center justify-center shadow-sm hover:shadow-md hover:-translate-y-0.5">
              <Copy className="mr-2 w-4 h-4" /> Copy postcard to clipboard
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
