export const translations: Record<string, Record<string, string>> = {
  en: {
    welcomeBar: "Padharo Mhare Desh — Welcome to the Majestic Land of Rajasthan",
    subtitle: "Discover the Land of Kings",
    navHome: "Home",
    navPlanner: "Smart Planner",
    navCulture: "Culture & Food",
    navInteractive: "Sensory Chamber",
    navLogin: "Maharaja Login",
    khammaGhani: "KHAMMA GHANI",
    heroTitle: "Experience Royal Rajasthan",
    heroSubtitle: "Explore historic forts, lake palaces, temple cities, wildlife reserves, traditional village craft hubs, and culinary kingdoms in one perfect planner.",
    btnStart: "Begin Planning Now",
    btnExplore: "Discover Culture",
    loginTitle: "Enter the Rajput Chamber",
    loginBtn: "Authenticate Login",
    step1: "1. Caravan Preference",
    step2: "2. Selection of Attractions",
    step3: "3. Optimized Itinerary",
    step4: "4. Budget Advisory",
    prefWhere: "Where does your royal caravan travel?",
    prefDays: "Number of Days",
    prefPeople: "Number of People",
    prefHotel: "Style of Stay",
    prefCategories: "Special Categories",
    prefTransport: "Mode of Caravan",
    btnNextPlaces: "Next: Selection of Attractions",
    currentPrefFilter: "Selected Preferences Parameters",
    btnGenItinerary: "Compile Smart Itinerary",
    itineraryTitle: "Your Optimized Travel Itinerary Plan"
  },
  hi: {
    welcomeBar: "पधारो म्हारे देस — राजस्थान की पावन भूमि पर आपका हार्दिक स्वागत है",
    subtitle: "महाराजाओं की गौरवशाली वीर भूमि",
    navHome: "मुख्य पृष्ठ",
    navPlanner: "स्मार्ट प्लानर",
    navCulture: "संस्कृति और व्यंजन",
    navInteractive: "सेंसर चैंबर",
    navLogin: "शाही लॉगिन",
    khammaGhani: "खम्मा घणी सा!",
    heroTitle: "शाही राजस्थान का वैभव",
    heroSubtitle: "ऐतिहासिक किलों, झीलों के महलों, पावन मंदिरों, वन्यजीव अभ्यारण्यों और पारंपरिक ग्राम शिल्प केंद्रों की जादुई यात्रा का शुभारंभ करें।",
    btnStart: "योजना प्रारंभ करें",
    btnExplore: "संस्कृति जानें",
    loginTitle: "शाही दरबार में प्रवेश करें",
    loginBtn: "प्रवेश सत्यापित करें",
    step1: "१. प्राथमिकताएं",
    step2: "२. आकर्षणों का चयन",
    step3: "३. अनुकूलित यात्रा कार्यक्रम",
    step4: "४. बजट परामर्श",
    prefWhere: "आपका शाही कारवां कहां प्रस्थान करेगा?",
    prefDays: "दिनों की संख्या",
    prefPeople: "यात्रियों की संख्या",
    prefHotel: "आवास की श्रेणी",
    prefCategories: "विशेष श्रेणियां",
    prefTransport: "परिवहन का माध्यम",
    btnNextPlaces: "आगे: आकर्षणों का चयन",
    currentPrefFilter: "चयनित प्राथमिकताओं के मानदंड",
    btnGenItinerary: "यात्रा कार्यक्रम तैयार करें",
    itineraryTitle: "आपका विशेष शाही यात्रा कार्यक्रम"
  },
  ra: {
    welcomeBar: "केसरिया बालम आओ नी, पधारो म्हारे देस सा!",
    subtitle: "राजा-महाराजा री अमर धरत",
    navHome: "मुख्य पानो",
    navPlanner: "शाही प्लानर",
    navCulture: "रीत-रिवाज अर जीमण",
    navInteractive: "शाही सेंसर",
    navLogin: "खातो खोलो सा",
    khammaGhani: "खम्मा घणी सा!",
    heroTitle: "रंगीलो राजस्थान रो शाही वैभव",
    heroSubtitle: "गढ़-किल्ला, महल-अटारियां, पवित्र देवल, और अनोखा थार मरुस्थल रो सफारी। म्हारो शाही एआई थारी सेवा मांय हाजिर है सा।",
    btnStart: "सफ़र री तैयारी करो सा",
    btnExplore: "पैल संस्कृति जाणो",
    loginTitle: "शाही दरबार मांय आवो सा",
    loginBtn: "दरबार में दाखलो",
    step1: "१. पसंद-नापसंद",
    step2: "२. चुणिंदा जागा",
    step3: "३. शाही सफ़रनामो",
    step4: "४. खरचो अर मौसम",
    prefWhere: "थारो शाही कारवां कठै कठै पधारसी सा?",
    prefDays: "कतरा दिन रो सफ़र?",
    prefPeople: "कतरा मिनख पधारसी?",
    prefHotel: "रैण-बसेरा री पसंद",
    prefCategories: "सफ़र री जात",
    prefTransport: "सवारी री पसंद",
    btnNextPlaces: "आगै: चुणियोड़ी जागा देखो",
    currentPrefFilter: "अबे री पसंद रो फ़िल्टर",
    btnGenItinerary: "शाही सफ़रनामो बणाओ सा",
    itineraryTitle: "थारो म्हारो अपणो शाही सफ़रनामो"
  }
};

export const attractionDetailsInfo: Record<string, any> = {
  'Lake Pichola Boat Ride': {
    description: 'Experience the serene beauty of Udaipur by taking a boat ride on the artificial freshwater Lake Pichola. Sail past the magnificent Jag Mandir and Taj Lake Palace.',
    timings: '09:00 AM - 06:00 PM',
    fee: '₹400 (Day), ₹800 (Sunset)',
    tip: 'The sunset boat ride offers the most magical golden hour views of the City Palace complex.',
    image: 'https://images.unsplash.com/photo-1615836245337-f5b9b230bc18?auto=format&fit=crop&w=600&q=80'
  },
  'Saheliyon Ki Bari': {
    description: 'A beautiful 18th-century garden designed for the royal ladies of Mewar, featuring marble pavilions, lotus pools, and elephant-shaped fountains.',
    timings: '09:00 AM - 07:00 PM',
    fee: '₹20 (Indians), ₹50 (Foreigners)',
    tip: 'Perfect for a peaceful morning stroll before the crowds arrive.',
    image: 'https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&w=600&q=80'
  },
  'Sajjangarh Monsoon Palace': {
    description: 'A hilltop palatial residence overlooking the Fateh Sagar Lake, built to watch monsoon clouds. It offers the most spectacular sunset views over Udaipur.',
    timings: '09:00 AM - 06:00 PM',
    fee: '₹100 (Indians), ₹300 (Foreigners)',
    tip: 'Take a shared taxi from the base gate to the top to save time.',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=600&q=80'
  },
  'City Palace Udaipur': {
    description: 'A majestic architectural marvel towering over Lake Pichola. This massive complex consists of 11 separate palaces built over 400 years by different rulers.',
    timings: '09:30 AM - 05:30 PM',
    fee: '₹300 (Adults), ₹100 (Children)',
    tip: 'Do not miss the Crystal Gallery and the vintage car museum located nearby.',
    image: 'https://images.unsplash.com/photo-1603258591321-df626c11d2bc?auto=format&fit=crop&w=600&q=80'
  },
  'Jaswant Thada Cenotaph': {
    description: 'A stunning white marble cenotaph built in 1899 in memory of Maharaja Jaswant Singh II, often called the Taj Mahal of Marwar.',
    timings: '09:00 AM - 05:00 PM',
    fee: '₹30 (Indians), ₹50 (Foreigners)',
    tip: 'The garden grounds offer a remarkably peaceful spot with excellent views of Mehrangarh Fort.',
    image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=600&q=80'
  },
  'Mandore Gardens': {
    description: 'The ancient capital of Marwar before Jodhpur was founded. Features beautifully carved cenotaphs, a hall of heroes, and a temple dedicated to 33 crore Hindu deities.',
    timings: '08:00 AM - 08:00 PM',
    fee: 'Free Entrance (Museum ₹50)',
    tip: 'Be aware of the aggressive langur monkeys in the area.',
    image: 'https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&w=600&q=80'
  },
  'Patwon Ki Haveli': {
    description: 'The most important and largest haveli in Jaisalmer. It is actually a cluster of five massive houses featuring incredibly intricate yellow sandstone carvings.',
    timings: '09:00 AM - 05:00 PM',
    fee: '₹50 (Indians), ₹100 (Foreigners)',
    tip: 'Look for the tiny mirror works and the traditional wall paintings inside.',
    image: 'https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?auto=format&fit=crop&w=600&q=80'
  },
  'Sam Sand Dunes Camel Ride': {
    description: 'Experience the raw Thar Desert with a traditional camel back ride across the sweeping golden dunes.',
    timings: '04:00 PM - 07:00 PM',
    fee: 'Varies (Approx ₹500-₹1500)',
    tip: 'Negotiate the ride duration before paying. Sunset rides are highly recommended.',
    image: 'https://images.unsplash.com/photo-1589308078059-be1415eab4c3?auto=format&fit=crop&w=600&q=80'
  },
  'Desert Sunset Jeep Safari': {
    description: 'A thrilling off-road 4x4 jeep adventure bashing through the massive sand dunes of the Thar desert.',
    timings: '03:00 PM - 07:00 PM',
    fee: 'Varies (Approx ₹1200-₹2000 per jeep)',
    tip: 'Hold on tight! This is a bumpy but exhilarating ride.',
    image: 'https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=600&q=80'
  },
  'Dilwara Jain Temples': {
    description: 'World-renowned Jain temples known for their extraordinary architecture and marvelous marble stone carvings, built between the 11th and 13th centuries.',
    timings: '12:00 PM - 06:00 PM',
    fee: 'Free Entrance',
    tip: 'Photography is strictly prohibited inside. Dress modestly (legs and shoulders must be covered).',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=600&q=80'
  },
  'Nakki Lake Boating': {
    description: 'A serene ancient sacred lake situated at the heart of Mount Abu, surrounded by hills, parks, and strange rock formations.',
    timings: '09:30 AM - 06:00 PM',
    fee: '₹150-₹400 (Depending on boat type)',
    tip: 'Paddle boats are fun, but consider a rowboat for a more relaxing experience.',
    image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=600&q=80'
  },
  'Pushkar Lake Ghats & Parikrama': {
    description: 'One of the most sacred lakes for Hindus, surrounded by 52 bathing ghats and hundreds of milky-blue temples.',
    timings: 'Open 24 Hours',
    fee: 'Free Entrance',
    tip: 'Take off your shoes when walking on the ghats. Experience the magical evening Maha Aarti.',
    image: 'https://images.unsplash.com/photo-1602738328654-51ab2ae6c4ff?auto=format&fit=crop&w=600&q=80'
  },
  'Junagarh Fort': {
    description: 'An unconquered 16th-century fort in Bikaner known for its gorgeous interiors blending Rajput, Gujarati, and Mughal architectural styles.',
    timings: '10:00 AM - 04:30 PM',
    fee: '₹50 (Indians), ₹300 (Foreigners)',
    tip: 'Explore the Anup Mahal and Badal Mahal for incredibly ornate wall paintings.',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80'
  },
  'Karni Mata Temple': {
    description: 'The famous "Rat Temple" of Rajasthan. Thousands of holy rats (kabbas) roam freely and are revered by devotees.',
    timings: '04:00 AM - 10:00 PM',
    fee: 'Free Entrance',
    tip: 'Spotting a white rat is considered highly auspicious.',
    image: 'https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&w=600&q=80'
  },
  'Ranthambore National Park': {
    description: 'One of the best places in India to see Bengal Tigers in the wild, set against the backdrop of ancient ruins and dry deciduous forests.',
    timings: '06:30 AM - 10:00 AM, 02:30 PM - 06:00 PM',
    fee: 'Varies based on zone and vehicle (Safari requires advance booking)',
    tip: 'Book safaris months in advance online. Zones 1-5 generally have higher tiger sighting probabilities.',
    image: 'https://images.unsplash.com/photo-1603258591321-df626c11d2bc?auto=format&fit=crop&w=600&q=80'
  },
  'Dal Bati Churma': {
    description: 'The quintessential Rajasthani dish. Round wheat flour bread baked over coals (Bati), served with spicy lentils (Dal) and sweet crushed bati mixed with ghee (Churma).',
    timings: 'Lunch & Dinner',
    fee: 'Approx ₹300-₹800',
    tip: 'Best enjoyed with hands! Ask for extra ghee on the Bati.',
    image: 'https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=600&q=80'
  },
  'Laal Maas': {
    description: 'A fiery traditional Rajasthani mutton curry cooked with fiery Mathania red chilies, garlic, and yogurt.',
    timings: 'Dinner',
    fee: 'Approx ₹500-₹1200',
    tip: 'Extremely spicy! Pair it with Bajra (Pearl millet) roti or plain rice to balance the heat.',
    image: 'https://images.unsplash.com/photo-1589308078059-be1415eab4c3?auto=format&fit=crop&w=600&q=80'
  },
  'Ghevar': {
    description: 'A disc-shaped sweet made from all-purpose flour and soaked in sugar syrup. Very popular during the Teej festival.',
    timings: 'Anytime',
    fee: 'Approx ₹150-₹400/piece',
    tip: 'Try the Malai Ghevar variant for a richer, creamier experience.',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80'
  },
  'Pyaaz Kachori': {
    description: 'A popular deep-fried spicy snack stuffed with a fiery onion filling. Originating from Jodhpur but famous everywhere.',
    timings: 'Breakfast or Evening Snack',
    fee: 'Approx ₹30-₹60/piece',
    tip: 'Eat it hot, served with sweet tamarind chutney and spicy coriander chutney.',
    image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=600&q=80'
  },

  'Amer Fort': {
    description: 'Overlooking Maota Lake near Jaipur, Amer Fort was built by Raja Man Singh. It features spectacular Hindu element archways, cobble pathways, and the stunning Sheesh Mahal (mirror room) where one candle illuminates the entire hall.',
    timings: '08:00 AM - 05:30 PM, 06:30 PM - 09:15 PM',
    fee: '₹100 for Indian Tourists, ₹500 for Foreigners',
    tip: 'Do not miss the majestic sound & light show held in the evening. Uphill walking paths require comfortable shoes.',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=600&q=80'
  },
  'Nahargarh Fort': {
    description: 'Standing proudly on the edge of the Aravalli hills, Nahargarh provides the most iconic panoramic views of Jaipur. Built in 1734 by Sawai Jai Singh II as a peaceful mountain retreat.',
    timings: '10:00 AM - 05:30 PM',
    fee: '₹50 (Indians), ₹200 (Foreigners)',
    tip: 'Visit during the late evening sunset. The open air restaurants at the top are perfect for night-photography.',
    image: 'https://images.unsplash.com/photo-1603258591321-df626c11d2bc?auto=format&fit=crop&w=600&q=80'
  },
  'Jaigarh Fort': {
    description: 'Built to guard Amer Fort, Jaigarh hosts the massive "Jaivana Cannon" - which was once the worlds largest cannon on wheels. It boasts a complex network of ancient rainwater harvesting tanks.',
    timings: '09:00 AM - 04:30 PM',
    fee: '₹35 (Indians), ₹85 (Foreigners)',
    tip: 'Take an authorized local guide to discover hidden subterranean defense passages.',
    image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=600&q=80'
  },
  'City Palace Jaipur': {
    description: 'Built by Sawai Jai Singh II, this imperial complex blends Mughal and Rajput design, featuring royal museums, Peacock Courtyard gateways, and traditional guard uniforms.',
    timings: '09:30 AM - 05:00 PM',
    fee: '₹200 (Indians), ₹700 (Foreigners)',
    tip: 'Upgrade tickets to get access to the private Chandra Mahal, which is still used by descendants of Jaipurs royals.',
    image: 'https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&w=600&q=80'
  },
  'Mehrangarh Fort': {
    description: 'Perched 410 feet above Jodhpur, this massive fortress is one of the grandest in India. Built in 1459 by Rao Jodha, its red-stone walls bear original royal battle scars.',
    timings: '09:00 AM - 05:00 PM',
    fee: '₹100 (Indians), ₹600 (Foreigners)',
    tip: 'Try the Flying Fox zipline course over Jodhpurs blue-colored village roofs for thrilling panoramas.',
    image: 'https://images.unsplash.com/photo-1504609773096-104ff2c73ba4?auto=format&fit=crop&w=600&q=80'
  },
  'Umaid Bhawan Palace': {
    description: 'One of the worlds largest private residential structures. Built with fine golden sandstone, a portion is run by Taj Hotels as a heritage stay, while another serves as a palace museum.',
    timings: '10:00 AM - 05:00 PM',
    fee: '₹30 (Museum Access Only)',
    tip: 'Explore the vintage car gallery within the gardens containing decades-old custom vehicles.',
    image: 'https://images.unsplash.com/photo-1589308078059-be1415eab4c3?auto=format&fit=crop&w=600&q=80'
  },
  'Jaisalmer Fort': {
    description: 'The "Sonar Qila" (Golden Fort) seems to rise directly from the sand of the Thar desert. Unlike other forts, it is a living citadel, containing homes, shops, and multi-century old temples.',
    timings: '09:00 AM - 06:00 PM',
    fee: '₹50 (Indians), ₹250 (Foreigners)',
    tip: 'Walk through the old sand lanes during sunrise/sunset, when the stone turns into gold colors.',
    image: 'https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=600&q=80'
  },
  'Chittorgarh Fort': {
    description: 'The epitome of Rajput bravery. Extending across an entire plateau, it is Indias largest fort, featuring the Victory Tower (Vijay Stambha) and classic stone lakes.',
    timings: '09:45 AM - 06:00 PM',
    fee: '₹40 (Indians), ₹350 (Foreigners)',
    tip: 'Hire an auto-rickshaw at the entry gates, as monuments inside are situated far apart.',
    image: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=600&q=80'
  },
  'Kumbhalgarh Fort': {
    description: 'Known for its continuous perimeter wall extending across 36 kilometers, second only to the Great Wall of China. Located high up in the rugged Aravalli mountains.',
    timings: '09:00 AM - 06:00 PM',
    fee: '₹40 (Indians), ₹600 (Foreigners)',
    tip: 'Best visited during monsoons, when thick clouds settle over the mountain bastions.',
    image: 'https://images.unsplash.com/photo-1605649487212-47bdab064df7?auto=format&fit=crop&w=600&q=80'
  },
  'Khatu Shyam Ji': {
    description: 'A highly sacred temple dedicated to Barbarika (manifestation of Lord Krishna). Renowned for its pristine white marble structure that attracts millions of devotees seeking blessings.',
    timings: '04:30 AM - 12:30 PM, 04:00 PM - 10:00 PM',
    fee: 'Free Entrance',
    tip: 'Avoid visiting during Shukla Paksha Ekadashi unless you wish to join long pilgrim queues.',
    image: 'https://images.unsplash.com/photo-1602738328654-51ab2ae6c4ff?auto=format&fit=crop&w=600&q=80'
  },
  'Salasar Balaji': {
    description: 'A prominent temple dedicated to Lord Hanuman in Churu. The idol represents Hanuman with a beard and mustache, unique in traditional Hindu mythology.',
    timings: '04:00 AM - 10:00 PM',
    fee: 'Free Entrance',
    tip: 'The temple community kitchen serves hot, nutritious traditional meals to all visitors without charge.',
    image: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80'
  },
  'Brahma Temple': {
    description: 'Located next to the holy lake of Pushkar, this is one of the extremely rare temples in the entire world dedicated to Lord Brahma, dating back to the 14th century.',
    timings: '06:00 AM - 09:00 PM',
    fee: 'Free Entrance',
    tip: 'Be cautious of self-proclaimed local priests asking for hefty donations near Pushkar Lake ghats.',
    image: 'https://images.unsplash.com/photo-1590005354167-6da97870c913?auto=format&fit=crop&w=600&q=80'
  },
  'Hawa Mahal': {
    description: 'The famed Palace of Winds. Built in 1799 with pink sandstone, its unique honeycombed exterior boasts 953 screens to allow cool breezes to flow through the private chambers.',
    timings: '09:00 AM - 05:30 PM',
    fee: '₹50 (Indians), ₹200 (Foreigners)',
    tip: 'Cross the main street to the opposite rooftops for the absolute best photographic compositions.',
    image: 'https://images.unsplash.com/photo-1603258591321-df626c11d2bc?auto=format&fit=crop&w=600&q=80'
  },
  'Jantar Mantar': {
    description: 'A UNESCO World Heritage site consisting of 19 precision stone astronomical observation devices constructed by King Jai Singh II, including the worlds largest sundial.',
    timings: '09:00 AM - 04:30 PM',
    fee: '₹50 (Indians), ₹300 (Foreigners)',
    tip: 'Hiring a certified astronomer guide is highly recommended to understand how these huge stone dials read time.',
    image: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=600&q=80'
  }
};

export const cityDaysDatabase: Record<string, any[]> = {
  'Jaipur': [
    { title: "Jaipur Legacy Highlights", spots: ["Hawa Mahal", "City Palace Jaipur", "Jantar Mantar"], time: "09:00 AM - 07:00 PM" },
    { title: "Jaipur Fortified Majesty", spots: ["Amer Fort", "Nahargarh Fort", "Jaigarh Fort"], time: "08:30 AM - 10:00 PM" }
  ],
  'Udaipur': [
    { title: "Romantic Lake Pichola Experience", spots: ["City Palace Udaipur", "Lake Pichola Boat Ride"], time: "09:00 AM - 08:30 PM" },
    { title: "Scenic Panoramas & Gardens", spots: ["Saheliyon Ki Bari", "Sajjangarh Monsoon Palace"], time: "09:30 AM - 07:00 PM" }
  ],
  'Jodhpur': [
    { title: "Jodhpur Blue City Heritage", spots: ["Mehrangarh Fort", "Jaswant Thada Cenotaph"], time: "08:30 AM - 06:00 PM" },
    { title: "Royal Retreats", spots: ["Umaid Bhawan Palace", "Mandore Gardens"], time: "09:00 AM - 05:30 PM" }
  ],
  'Jaisalmer': [
    { title: "Jaisalmer Living Golden Fort", spots: ["Jaisalmer Fort", "Patwon Ki Haveli"], time: "09:00 AM - 06:30 PM" },
    { title: "Thar Desert Dunes & Safaris", spots: ["Sam Sand Dunes Camel Ride", "Desert Sunset Jeep Safari"], time: "03:00 PM - 11:30 PM" }
  ],
  'Mount Abu': [
    { title: "Hill Station Escapes", spots: ["Dilwara Jain Temples", "Nakki Lake Boating"], time: "09:00 AM - 07:00 PM" }
  ],
  'Pushkar': [
    { title: "Pushkar Sacred Lakes & Temples", spots: ["Brahma Temple", "Pushkar Lake Ghats & Parikrama"], time: "05:30 AM - 08:00 PM" }
  ],
  'Bikaner': [
    { title: "Junagarh Fortified Legacies", spots: ["Junagarh Fort", "Karni Mata Temple"], time: "09:00 AM - 06:00 PM" }
  ],
  'Ranthambore': [
    { title: "Wild Tiger Safaris", spots: ["Ranthambore National Park", "Kumbhalgarh Fort"], time: "06:00 AM - 05:00 PM" }
  ],
  'Chittorgarh': [
    { title: "Chittorgarh Fort Valour", spots: ["Chittorgarh Fort"], time: "08:30 AM - 05:30 PM" }
  ]
};

export const weatherDatabase: Record<string, any> = {
  'Jaipur': { temp: '32', rain: '10', wind: '12' },
  'Udaipur': { temp: '29', rain: '18', wind: '10' },
  'Jodhpur': { temp: '35', rain: '5', wind: '16' },
  'Jaisalmer': { temp: '39', rain: '2', wind: '22' },
  'Mount Abu': { temp: '22', rain: '35', wind: '14' },
  'Pushkar': { temp: '31', rain: '8', wind: '11' },
  'Bikaner': { temp: '36', rain: '4', wind: '18' },
  'Ranthambore': { temp: '33', rain: '15', wind: '9' },
  'Chittorgarh': { temp: '30', rain: '12', wind: '10' }
};

export const vectorMapNodes = [
  { name: 'Jaipur', x: 320, y: 160 },
  { name: 'Udaipur', x: 210, y: 290 },
  { name: 'Jodhpur', x: 230, y: 180 },
  { name: 'Jaisalmer', x: 110, y: 190 },
  { name: 'Mount Abu', x: 150, y: 310 },
  { name: 'Pushkar', x: 280, y: 175 },
  { name: 'Bikaner', x: 220, y: 110 },
  { name: 'Ranthambore', x: 350, y: 210 },
  { name: 'Chittorgarh', x: 260, y: 260 }
];

export const destinationsList = ['Jaipur', 'Udaipur', 'Jodhpur', 'Jaisalmer', 'Mount Abu', 'Pushkar', 'Bikaner', 'Ranthambore', 'Chittorgarh'];

export const attractionsData: Record<string, string[]> = {
  "Historical Forts": ['Amer Fort', 'Nahargarh Fort', 'Jaigarh Fort', 'City Palace Jaipur', 'Mehrangarh Fort', 'Umaid Bhawan Palace', 'Jaisalmer Fort', 'Chittorgarh Fort', 'Kumbhalgarh Fort', 'Junagarh Fort', 'City Palace Udaipur'],
  "Spiritual Temples": ['Khatu Shyam Ji', 'Salasar Balaji', 'Brahma Temple', 'Karni Mata Temple', 'Dilwara Jain Temples', 'Jaswant Thada Cenotaph'],
  "Wildlife Preserves": ['Ranthambore National Park'],
  "Architecture Highlights": ['Hawa Mahal', 'Jantar Mantar', 'Patwon Ki Haveli', 'Saheliyon Ki Bari', 'Sajjangarh Monsoon Palace'],
  "Experiences": ['Lake Pichola Boat Ride', 'Sam Sand Dunes Camel Ride', 'Desert Sunset Jeep Safari', 'Nakki Lake Boating', 'Pushkar Lake Ghats & Parikrama', 'Mandore Gardens'],
  "Famous Food": ['Dal Bati Churma', 'Laal Maas', 'Ghevar', 'Pyaaz Kachori']
};

export const budgetRows = [
  { cat: 'Hotel & Palace Retreater stays', ratio: '35%', multiplier: 0.35 },
  { cat: 'Gastronomy & Traditional meals', ratio: '15%', multiplier: 0.15 },
  { cat: 'Intercity Transport & Fuel factors', ratio: '22%', multiplier: 0.22 },
  { cat: 'Attraction Monument Tickets & Guides', ratio: '12%', multiplier: 0.12 },
  { cat: 'Desert Safaris & Cultural events', ratio: '16%', multiplier: 0.16 }
];
