export type Page = 'home' | 'login' | 'planner' | 'explore' | 'interactive';
export type Language = 'en' | 'hi' | 'ra';

export interface ToastMessage {
  id: number;
  msg: string;
}

export interface ChatMessage {
  id: number;
  sender: 'user' | 'bot';
  text: string;
}

export interface ModalData {
  name: string;
  category: string;
  description: string;
  timings: string;
  fee: string;
  tip: string;
  image: string;
}

export interface PlannerForm {
  destinations: string[];
  days: string;
  people: string;
  categories: string[];
  accommodation: string;
  transport: string;
}
